//! LiveAct-RS web frontend (Rust -> WASM, no JS framework).
//!
//! Entry point: `start()`, called by the bootstrap snippet in index.html.

mod app;
mod audio;
mod avatar;
mod dom;
mod expression;
mod net;
mod viseme;

use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn start() -> Result<(), JsValue> {
    let app = app::boot().map_err(|e| JsValue::from_str(&e))?;
    app::wire_ui(&app);
    app::start_render_loop(app);
    Ok(())
}
