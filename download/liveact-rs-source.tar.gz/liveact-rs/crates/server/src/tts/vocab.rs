//! Kokoro-82M input vocabulary, taken verbatim from the model's own
//! `config.json` (`vocab`) plus the pad token `$` (id 0, per
//! tokenizer.json). Ids are sparse: the embedding has 178 rows but only
//! these 115 symbols are valid tokens.

use std::collections::HashMap;
use std::sync::OnceLock;

pub struct Vocab {
    pub forward: HashMap<char, usize>,
    pub reverse: HashMap<usize, char>,
}

const ENTRIES: &[(char, usize)] = &[
    ('$', 0),
    (';', 1),
    (':', 2),
    (',', 3),
    ('.', 4),
    ('!', 5),
    ('?', 6),
    ('\u{2014}', 9),
    ('\u{2026}', 10),
    ('\u{22}', 11),
    ('(', 12),
    (')', 13),
    ('\u{201c}', 14),
    ('\u{201d}', 15),
    (' ', 16),
    ('\u{303}', 17),
    ('\u{2a3}', 18),
    ('\u{2a5}', 19),
    ('\u{2a6}', 20),
    ('\u{2a8}', 21),
    ('\u{1d5d}', 22),
    ('\u{ab67}', 23),
    ('A', 24),
    ('I', 25),
    ('O', 31),
    ('Q', 33),
    ('S', 35),
    ('T', 36),
    ('W', 39),
    ('Y', 41),
    ('\u{1d4a}', 42),
    ('a', 43),
    ('b', 44),
    ('c', 45),
    ('d', 46),
    ('e', 47),
    ('f', 48),
    ('h', 50),
    ('i', 51),
    ('j', 52),
    ('k', 53),
    ('l', 54),
    ('m', 55),
    ('n', 56),
    ('o', 57),
    ('p', 58),
    ('q', 59),
    ('r', 60),
    ('s', 61),
    ('t', 62),
    ('u', 63),
    ('v', 64),
    ('w', 65),
    ('x', 66),
    ('y', 67),
    ('z', 68),
    ('\u{251}', 69),
    ('\u{250}', 70),
    ('\u{252}', 71),
    ('\u{e6}', 72),
    ('\u{3b2}', 75),
    ('\u{254}', 76),
    ('\u{255}', 77),
    ('\u{e7}', 78),
    ('\u{256}', 80),
    ('\u{f0}', 81),
    ('\u{2a4}', 82),
    ('\u{259}', 83),
    ('\u{25a}', 85),
    ('\u{25b}', 86),
    ('\u{25c}', 87),
    ('\u{25f}', 90),
    ('\u{261}', 92),
    ('\u{265}', 99),
    ('\u{268}', 101),
    ('\u{26a}', 102),
    ('\u{29d}', 103),
    ('\u{26f}', 110),
    ('\u{270}', 111),
    ('\u{14b}', 112),
    ('\u{273}', 113),
    ('\u{272}', 114),
    ('\u{274}', 115),
    ('\u{f8}', 116),
    ('\u{278}', 118),
    ('\u{3b8}', 119),
    ('\u{153}', 120),
    ('\u{279}', 123),
    ('\u{27e}', 125),
    ('\u{27b}', 126),
    ('\u{281}', 128),
    ('\u{27d}', 129),
    ('\u{282}', 130),
    ('\u{283}', 131),
    ('\u{288}', 132),
    ('\u{2a7}', 133),
    ('\u{28a}', 135),
    ('\u{28b}', 136),
    ('\u{28c}', 138),
    ('\u{263}', 139),
    ('\u{264}', 140),
    ('\u{3c7}', 142),
    ('\u{28e}', 143),
    ('\u{292}', 147),
    ('\u{294}', 148),
    ('\u{2c8}', 156),
    ('\u{2cc}', 157),
    ('\u{2d0}', 158),
    ('\u{2b0}', 162),
    ('\u{2b2}', 164),
    ('\u{2193}', 169),
    ('\u{2192}', 171),
    ('\u{2197}', 172),
    ('\u{2198}', 173),
    ('\u{1d7b}', 177)
];

pub static VOCAB: OnceLock<Vocab> = OnceLock::new();

pub fn vocab() -> &'static Vocab {
    VOCAB.get_or_init(|| {
        let mut forward = HashMap::new();
        let mut reverse = HashMap::new();
        for &(ch, id) in ENTRIES {
            forward.insert(ch, id);
            reverse.insert(id, ch);
        }
        Vocab { forward, reverse }
    })
}

pub fn tokenize(phonemes: &str) -> Vec<i64> {
    let v = vocab();
    phonemes
        .chars()
        .filter_map(|c| v.forward.get(&c).map(|&i| i as i64))
        .collect()
}
