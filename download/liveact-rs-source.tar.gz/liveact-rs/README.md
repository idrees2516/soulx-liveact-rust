# LiveAct-RS

**A system-level Rust reimplementation of [SoulX-LiveAct](https://github.com/Soul-AILab/SoulX-LiveAct): a real-time, streaming talking-avatar system — server *and* frontend in 100% Rust, using the 82 MB Kokoro-82M TTS model.**

Live deployment: **https://8080-agq7tznykj3vpll2i2zm63cmjm.instabox.tech**

```
┌──────────────────────────── Browser (Rust → WASM) ───────────────────────────┐
│  liveact-web (wasm-bindgen, no JS framework)                                │
│   • WebSocket client  • Web Audio PCM scheduler (24 kHz)                    │
│   • Viseme timeline eval + coarticulation blending                          │
│   • Procedural avatar renderer (canvas 2D): lipsync, emotions, gestures     │
│   • Timed segment editor, image backdrop, audio-driven mode, live queue     │
└──────────────▲───────────────────────────────────────┬──────────────────────┘
        JSON events (viseme timeline, progress)         │ PCM16 binary frames
               │                                        ▼
┌──────────────┴──────────────────────── Axum server (native) ────────────────┐
│  liveact-server                                                              │
│   • /ws  session pipeline: sentence chunks, bounded 14 s look-ahead, O(1)    │
│     session memory (hour-scale safe — the ConvKV-Memory property)            │
│   • Kokoro-82M TTS: espeak-ng → IPA → kokoro vocab → ONNX (ort, CPU)         │
│     timestamped model: waveform + per-token durations (hop 600 @ 24 kHz)     │
│   • Static frontend embedded in the binary (include_dir)                     │
└──────────────────────────────────────────────────────────────────────────────┘
```

## Mapping to the original SoulX-LiveAct system

| SoulX-LiveAct (Python, 2×H100) | LiveAct-RS (Rust, CPU-only) |
| --- | --- |
| Flask server + HLS video stream | Axum server + WebSocket audio/animation stream |
| Wan2.1 diffusion video model (18B) | Real-time procedural avatar renderer (WASM, canvas) |
| Kokoro TTS (PyTorch) | Kokoro-82M ONNX `q8f16` (**82 MB**) via `ort` + espeak-ng FFI |
| wav2vec2 audio features → lip sync | Per-token `durations` from the timestamped model → viseme timeline |
| Neighbor Forcing (cross-chunk consistency) | Coarticulation blending across viseme/chunk boundaries |
| ConvKV Memory (constant memory, hour-scale) | Bounded look-ahead pipeline + pruned timelines (O(1) memory) |
| Timed "Edit Prompt" segments | Same: timed segments → expressions/gestures (smile, wave, nod, …) |
| Task status: chunks / stream-ready / done | Same fields, live (plus RTF, buffer, latency) |
| cond_image + cond_audio inputs | Backdrop image upload + audio-driven mode (energy lipsync) |

The 18B diffusion model cannot run on CPU; the avatar renderer replaces it
1:1 at the system level (same streaming contract: text in → timed animation
+ audio out), which keeps the whole architecture faithful while running on
a single 4-vCPU cloud machine.

## Performance (4 vCPU InstaBox machine)

- **RTF ≈ 0.42–0.45** (synthesizes ~2.2× faster than real time)
- First chunk (TTFA) ≈ 0.4–0.6 s; chunk streaming adds ~10–40 ms per chunk
- 20 bundled voices (en-us, en-gb, es, fr, hi, it, pt), 24 kHz mono PCM
- Server binary: ~22 MB, models: 82 MB + ~10 MB voices

## Build & run

Requirements: Rust (stable), `espeak-ng` + `libespeak-ng1` (runtime data),
optional `wasm-pack` (only if you change the frontend — a prebuilt `pkg`
is committed under `assets/dist/pkg`).

```bash
./scripts/fetch_models.sh                 # 82 MB model + voices
wasm-pack build crates/web --target web --release --out-dir ../../assets/dist/pkg  # optional
cargo build --release -p liveact-server
LIVEACT_ADDR=0.0.0.0:8080 ./target/release/liveact-server
```

Environment variables:

| Var | Default | Meaning |
| --- | --- | --- |
| `LIVEACT_ADDR` | `0.0.0.0:8080` | Listen address |
| `LIVEACT_MODELS` | `models` | Model directory |
| `LIVEACT_MODEL` | `<models>/kokoro-q8f16.onnx` | Any Kokoro v1.0 ONNX (fp32 `model.onnx` gives ~3× faster RTF at 310 MB) |
| `LIVEACT_ESPEAK_DATA` | auto-detected | Directory containing `espeak-ng-data` |
| `LIVEACT_ORT_OPT` | off | Re-enable ORT graph optimization (off by default: ORT 1.23.2 segfaults on this graph during level-3 transforms) |

## Wire protocol (`/ws`)

JSON control frames (`type`-tagged, see `crates/proto`), binary frames are
`[u32 chunk_idx][u32 sample_count][i16 PCM …]` right after each
`chunk_start`. Client → server: `start` (script, voice, speed, segments),
`enqueue` (live queueing), `stop`, `ping`. Server → client: `hello`,
`started`, `chunk_start` (viseme spans with absolute timings), `chunk_end`,
`progress`, `done` (RTF), `error`, `pong`.

## Test

```bash
cargo test -p liveact-server          # phonemizer, normalizer, splitter, fixes
cargo run -p liveact-server --example smoke   # offline synth → smoke.wav + stats
```

## Deployment (InstaBox)

```bash
tar czf liveact-rs.tar.gz --exclude=liveact-rs/target --exclude=liveact-rs/models liveact-rs
curl -X PUT "https://api.instabox.sh/v1/machines/<id>/files?path=/data/home/liveact-rs.tar.gz&parents=true" \
     -H "X-API-Key: $INSTABOX_API_KEY" --data-binary @liveact-rs.tar.gz
# exec: tar xzf …, scripts/setup-machine.sh, then run the server on :8080
curl -X POST "https://api.instabox.sh/v1/machines/<id>/ports" \
     -H "X-API-Key: $INSTABOX_API_KEY" -H 'Content-Type: application/json' \
     -d '{"port": 8080, "name": "LiveAct-RS web"}'
```

## Notes & limitations

- Chinese/Japanese voices are not bundled (Kokoro zh requires pinyin-based
  phonemization; this pipeline is espeak-based, like the original repo's
  streaming kokoro path).
- Quantized models (`q8f16` 82 MB, `int8` 88 MB) carry unfused QDQ overhead
  on CPU; the fp32 graph (310 MB) reaches RTF ≈ 0.15 on the same machine.
  Switch with `LIVEACT_MODEL`.
- Credits: Kokoro-82M by hexgrad (Apache-2.0), ONNX builds by
  onnx-community, phonemization reference from misaki/kokoro-js/Kokoros.
